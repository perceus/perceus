int arch_init(void)
{
	return 0;
}
