#ifndef PURGATORY_H
#define PURGATORY_H

void putchar(int ch);
void sprintf(char *buffer, const char *fmt, ...);
void printf(const char *fmt, ...);
void setup_arch(void);
void post_verification_setup_arch(void);

#endif /* PURGATORY_H */
