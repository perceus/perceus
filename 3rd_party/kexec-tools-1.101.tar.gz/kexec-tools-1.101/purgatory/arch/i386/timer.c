#include <arch/io.h>
#include <purgatory.h>
#include "purgatory-x86.h"


void x86_setup_legacy_timer(void)
{
	/* Load the legacy timer settings into the 8254 pit */
}

