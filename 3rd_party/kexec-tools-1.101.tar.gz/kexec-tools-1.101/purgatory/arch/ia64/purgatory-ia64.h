#ifndef PURGATORY_IA64_H
#define PURGATORY_IA64_H

/* nothing yet */

#endif /* PURGATORY_IA64_H */
