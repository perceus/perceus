#include <purgatory.h>
#include "purgatory-ia64.h"

void setup_arch(void)
{
	/* Nothing for now */
}
