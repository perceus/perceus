#ifndef PURGATORY_PPC_H
#define PURGATORY_PPC_H

/* nothing yet */

#endif /* PURGATORY_PPC_H */
