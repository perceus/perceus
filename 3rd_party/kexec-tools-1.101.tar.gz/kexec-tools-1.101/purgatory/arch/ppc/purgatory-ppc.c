#include <purgatory.h>
#include "purgatory-ppc.h"

void setup_arch(void)
{
	/* Nothing for now */
}
