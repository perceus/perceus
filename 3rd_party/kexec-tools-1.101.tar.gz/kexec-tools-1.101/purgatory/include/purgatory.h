#ifndef PURGATORY_H
#define PURGATORY_H

void putchar(int ch);
void printf(const char *fmt, ...);
void setup_arch(void);

#endif /* PURGATORY_H */
