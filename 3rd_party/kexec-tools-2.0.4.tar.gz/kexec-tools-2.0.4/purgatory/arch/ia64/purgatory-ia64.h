#ifndef PURGATORY_IA64_H
#define PURGATORY_IA64_H

void reset_vga(void);
#endif /* PURGATORY_IA64_H */
