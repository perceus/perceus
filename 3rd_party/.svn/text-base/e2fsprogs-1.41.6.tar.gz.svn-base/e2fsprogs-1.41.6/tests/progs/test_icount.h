void do_create_icount(int argc, char **argv);
void do_free_icount(int argc, char **argv);
void do_fetch(int argc, char **argv);
void do_increment(int argc, char **argv);
void do_decrement(int argc, char **argv);
void do_store(int argc, char **argv);
void do_get_size(int argc, char **argv);
void do_dump(int argc, char **argv);
void do_validate(int argc, char **argv);

